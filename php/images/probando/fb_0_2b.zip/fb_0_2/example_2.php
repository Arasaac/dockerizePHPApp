<html>
        <head>
            <title>Salix.gr - Image File Browser demo page</title>
            <META NAME="author" CONTENT="Panos Kyriakakis">
            <meta name="description" lang="en" content="Demo page. Browse and choose images without page reloading">
            <meta name="keywords" lang="en" content="Demo page, Image File Browser, Content management, Components and tools to manage content, AJAX, Interact with the Web server without page reloading">
            <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
            <META name="verify-v1" content="2CKKXxDtxsHjE7TjmXjWJSzMj5xqXOvTrnZ27goGJSE=" />
            <META name="robots" content="follow,index" />
        </head>
    <body>
    <style>
body {
	background-color: #FFFFFF;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
	margin: 8px;
}

td {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}

input {
	background: #FFFFFF;
	border: 1px solid #cccccc;
}

td, input, select, textarea {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 10px;
}
fieldset {
	border: 1px solid #919B9C;
	font-family: Verdana, Arial;
	font-size: 10px;
	padding: 0px;
	margin: 0px;
	padding: 4px;
}

legend {
	color: #2B6FB6;
	font-weight: bold;
}
input, select, textarea {
	border: 1px solid #808080;
}
    </style>
    <h2><a href="http://www.salix.gr/image_browser_class">Salix.gr - Image File Browser Demo</a></h2>
<?php
    error_reporting(E_ALL);
    include("file_browser.class.php");    
    $abs_path = str_replace('\\','/',str_replace('C:','', dirname(__FILE__))).'/';

    $o = new File_browser();
    $o->init('file_browser.class.php',
                $abs_path."demo_images/",
                $abs_path."demo_images/",
                0,4,10,
                'file_browser_1',
                'img_view');

    $o->add_browser_jscripts('http://www.salix.gr/demos/ifb_demo/');
    $o->place_browser();
?>

    </body>
</html>