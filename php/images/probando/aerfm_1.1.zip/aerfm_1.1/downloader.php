<?
	    
	    $file=$_GET["file"];
	    header('Content-Type: unknown' );
	    header('Content-Disposition: Attachment; filename="' .basename($file). '"');
	    readfile($file);

?>