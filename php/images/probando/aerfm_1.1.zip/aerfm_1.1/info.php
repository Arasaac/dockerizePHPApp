
<?
phpinfo();
?>