<?

function tryftp($data)
	{
		$data=stripslashes('<?xml version="1.0"?> '.$data);
		$parser = xml_parser_create();
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, $data, $vals, $index);
		xml_parser_free($parser); 
		$ftp_server = $vals[0]["attributes"]["SERVER"];
		$ftp_user_name =  $vals[0]["attributes"]["USER"];
		$ftp_user_pass = $vals[0]["attributes"]["PWD"];
		
		if(($conn_id = @ftp_connect($ftp_server))!==false)
			{

			// login with username and password
			$login_result = @ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
			
			// check connection
			if ((!$conn_id) || (!$login_result)) {
			       echo "FTP connection has failed!";
			       echo "Attempted to connect to $ftp_server for user $ftp_user_name";
			       exit;
			   } else {
			       echo "Connected!";
			   }
			
			// close the FTP stream
			ftp_close($conn_id);	
		}
		else echo "Cannot connect to $ftp_server";
	}


$sexport[]="tryftp";
?>