<?
if(isset($_POST["savepath"]))
	{
	
	$name = rawurlencode($_FILES['uploadfile']['name']); 
	if(move_uploaded_file($_FILES['uploadfile']['tmp_name'],$_POST["savepath"]."/".$name))
	$message = "OK";
	else $message = "Can't save the file!";
	}


?>

<html>
	<head>
		<title>Test Upload Progress</title>
		</script>
	</head>
	<body style="font-family: sans-serif; font-size: 8pt;">
<script type="text/javascript"><!--

window.parent.upload_end("<?=$message?>");
-->
</script>
		<pre><?php var_dump($_POST); ?></pre>
	</body>
</html>