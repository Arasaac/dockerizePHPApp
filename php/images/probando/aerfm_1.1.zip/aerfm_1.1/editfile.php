<?
	if(is_file($_POST["path"]))
		{
			if (is_writable($_POST["path"])) {
			   if (!$handle = fopen($_POST["path"], 'w')) {
				  $message=  "Cannot open file: {$_POST["path"]})";
				 exit;
			   }
			if (fwrite($handle, urldecode ($_POST["filetext"])) === FALSE) {
			       $message=  "Cannot write to file: {$_POST["path"]}";
			       exit;
			   }
			$message=  "File saved!";
			fclose($handle);
			} else {
			   $message= "The file {$_POST["path"]} is not writable";
			}		
		}
?>
<html>
	<head>
		<title>File save</title>
		</script>
	</head>
	<body style="font-family: sans-serif; font-size: 8pt;">
<script type="text/javascript"><!--

window.parent.edit_end("<?=$message?>");
-->
</script>
		<pre><?php var_dump($_POST); ?></pre>
	</body>
</html>