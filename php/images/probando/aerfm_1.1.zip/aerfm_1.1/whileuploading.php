<?php
include 'config.php';
header('Content-Length: '.strlen($output));			// now headers to resolve browser cache problems
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');

// APPLICATION - PLEASE DON'T MODIFY
session_start();	
require('UploadProgressManager.class.php');			// The class UploadProgressManager class
					// need a session to be really efficient
clearstatcache();						// and maybe a cleared stats
$UPM = new UploadProgressManager($tmpdir);			// new UploadProgressManager with temporary upload folder
if(($output = $UPM->getTemporaryFileSize()) === false)		// if UPM class cannot find the temporary file
	$output = '&filesize=undefined';			// the output for LoadVars will be undefined
else
	$output = '&filesize='.$output;				// else the output will be temporary file size

echo $output;							// and finally the output for LoadVars
?>