<?
	
	function listdir($data)
		{
		$data=stripslashes('<?xml version="1.0"?> '.$data);
		$parser = xml_parser_create();
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, $data, $vals, $index);
		xml_parser_free($parser); 
		$actdir = $vals[0]["attributes"]["PATH"];
		$side=  $vals[0]["attributes"]["SIDE"];
		if(isset($vals[0]["attributes"]["SERVER"]))
		{
		$ftp_server = $vals[0]["attributes"]["SERVER"];
		$ftp_user_name =  $vals[0]["attributes"]["USER"];
		$ftp_user_pass = $vals[0]["attributes"]["PWD"];
		}
	global $_SERVER;
	
		function cutesize($number)
			{
			$i=0;
			$type = Array( '', 'k', 'M', 'G', 'T', 'Z' );
			while($number>1024)
				{
				$number= $number/1024;
				$i++;
				}
			return round($number, 1)."".$type[$i];
			}
		
	if(!isset($ftp_server) )
		{
	 //$root = realpath(dirname( $root).$actdir);
	 $root = realpath($actdir);
	// $actdir =  substr($root, strlen($root_));
	if (is_dir($root)) {
			$st = "<?xml version=\"1.0\"?>
			<directory side='$side' path='".$root."'>\n";
			
			if ($k_azon = @opendir($root)) {
			while (($fajl = readdir($k_azon)) !== false) {
			if(is_dir($root ."/".$fajl)&&$fajl!=".")
			{
			$t[]=$fajl;
			}}
			//var_dump($t);
			closedir($k_azon);
		if(is_array($t))
			{
			sort($t);
			foreach($t as $k=>$file)
				{
					$st .= "\n<entry ";	
					$st .= "type='".filetype($root ."/".$file)."' ";
					$st .= "name='".urlencode ($file)."' ";
					$st .="size='[DIR]' ";
					$st .="ctime='".date("Y-m-d H:i:s",filectime($root ."/". $file))."'";
					$st .=" perms='".substr(sprintf('%o', fileperms($root ."/". $file)), -4)."' />";
				}
			unset($t);
			}
			$k_azon = @opendir($root);
			while (($fajl = readdir($k_azon)) !== false) {
				if(is_file($root ."/".$fajl))
					$t[]=$fajl;
			}
			if(isset($t))
			{
			sort($t);
			foreach($t as $k=>$file)
				{
				$filetype = explode(".",$file);
				$st .= "\n<entry ";	
				$st .= "type='".strtolower($filetype[count($filetype)-1])."' ";
				$st .= "name='".rawurlencode ($file)."' ";
				$st .="size='".cutesize(filesize($root."/". $file))."' ";
				$st .="ctime='".date("Y-m-d H:i:s",filectime($root ."/". $file))."'";
				$st .=" perms='".substr(sprintf('%o', fileperms($root ."/". $file)), -4)."' />";
				}
			}
			$st .= "\n</directory>";	
			return $st;
			}
		}
		return false;
		}
		else // ftp konyvtar kilistazasa
			{
			$conn_id = @ftp_connect($ftp_server); 
			$login_result =@ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
			$actdir=  cleanPath($actdir);
			if(substr($actdir,-1,1)=="/")$actdir = substr($actdir,0,strlen($actdir)-1);
			
			$st = "<?xml version=\"1.0\"?>
			<directory side='$side' path='".$actdir."'>\n";
			if($actdir!="") $st .= "\n<entry ";	
				$st .= "type='dir' ";
				$st .= "name='..' ";
				$st .="size='[DIR]' ";
				$st .="ctime=''";
				$st .="/>";
			$t = ftp_nlist($conn_id, $actdir);
			if(is_array($t))
			{
			sort($t);
			foreach($t as $k=>$file)// konyvtarak
				{
					if( ftp_size($conn_id,  $actdir."/".$file)==-1)
					{
					$st .= "\n<entry ";	
					$st .= "type='dir' ";
					$st .= "name='".rawurlencode ($file)."' ";
					$st .="size='[DIR]' ";
					$st .="ctime='".date("Y-m-d H:i:s",ftp_mdtm($conn_id,  $actdir."/".$file))."'";
					//$st .=" perms='".substr(sprintf('%o', fileperms($root ."/". $file)), -4)."' />";
					$st .="/>";
					}
					else
					{
						$filetype = explode(".",$file);
						$st_ .= "\n<entry ";	
						$st_ .= "type='".strtolower($filetype[count($filetype)-1])."' ";
						$st_ .= "name='".rawurlencode ($file)."' ";
						$st_ .="size='".cutesize( ftp_size($conn_id, $actdir."/".$file))."' ";
						$st_ .="ctime='".date("Y-m-d H:i:s",ftp_mdtm($conn_id,  $actdir."/".$file))."'";
						//$st .=" perms='".substr(sprintf('%o', fileperms($root ."/". $file)), -4)."' />";
						$st_ .="/>";
					
					}
				}
				$st.=$st_ ;
			}
			$st .= "\n</directory>";	
			return $st;
			
			ftp_close($conn_id);
			}
		}
	function makedirectory($data)
		{
		$data=stripslashes('<?xml version="1.0"?> '.$data);
		$parser = xml_parser_create();
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, $data, $vals, $index);
		xml_parser_free($parser); 
		//$xml = simplexml_load_string($data);
		$path =  $vals[0]["attributes"]["PATH"];
		$dir = rawurlencode($vals[0]["attributes"]["DIR"]);
		global $_SERVER;
		$root = realpath($path );
		$path  =  realpath($path );
		if($dir=="")return "empty";
		if(is_dir($root."/".$dir)) return "exist";
		if(mkdir($root."/".$dir)) return "ok";
		else return "error";
		}
	function deletefile($data)
		{
		global $_SERVER;
		$data=stripslashes('<?xml version="1.0"?> '.$data);
		$parser = xml_parser_create();
		echo "<?xml version=\"1.0\"?>";
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, $data, $vals, $index);
		xml_parser_free($parser); 
		//$xml = simplexml_load_string($data);
		$path = $vals[0]["attributes"]["FILE"];
		$last = $vals[0]["attributes"]["LAST"];
		
		$file =  realpath($path);
		//if($dir!="/") $file = $dir."/".$file;
		if( is_file($file) )
			{
			if(unlink($file)) return "<message text='$file deleted.' error='0' refresh='$last'/>";
			else return "<message text='An error occoured.' error='1' refresh='$last'/>";
			}
		else return ("<message text='$file is not exist.' error='1' refresh='$last'/>");
		}
		
	function deletedir($data)
		{
		global $_SERVER;
		$data=stripslashes('<?xml version="1.0"?>'.$data);
		$parser = xml_parser_create();
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, $data, $vals, $index);
		xml_parser_free($parser); 
		//$xml = simplexml_load_string($data);
		$path = $vals[0]["attributes"]["DIR"];
		$last = $vals[0]["attributes"]["LAST"];
		
		$root = realpath( $path);
		if(is_dir($root))
			{
				if ($k_azon = opendir($root)) {
				while (false !== ($fajl = readdir($k_azon))) {
					if(filetype($root ."/".$fajl)=="dir"&&$fajl!=".."&&$fajl!=".") deletedir ("<message dir='".$path."/".$fajl."' last='0'/>");
					elseif(filetype($root ."/".$fajl)!="dir")
						{
						echo filetype($root ."/".$fajl);
						if(unlink ($root."/".$fajl))
						$st .= "<message text='".$path."/".$fajl." deleted.' error='0' refresh='0'/>\n";
						else $st .= "<message text='".$path."/".$fajl." not deleted.' error='1' refresh='0'/>\n";
						}
				   }
				   closedir($k_azon);
				   
				   if(rmdir($root))
					echo $st."<message text='$path deleted.' error='0' refresh='$last'/>\n";
				else echo $st."<message text='$path not deleted.' error='1' refresh='$last'/>\n";
				   
				}
			else echo $st."<message text='$path cannot open.' error='1' refresh='$last'/>\n";
			}
		else echo $st."<message text='$path is not a directory.' error='1' refresh='$last'/>\n";
		}
		
		
	function copyfile($data)
		{
		echo "<?xml version=\"1.0\"?>";
		$data=stripslashes('<?xml version="1.0"?> '.$data);
		$parser = xml_parser_create();
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, $data, $vals, $index);
		xml_parser_free($parser); 
		//$xml = simplexml_load_string($data);
		$from = $vals[0]["attributes"]["FROM"];
		$to = $vals[0]["attributes"]["TO"];
		$confirm = $vals[0]["attributes"]["CONFIRM"];
		$last = $vals[0]["attributes"]["LAST"];
		global $_SERVER;
		$fromfile = realpath($from );
		$filen =  basename($fromfile );
		$tofile  =  realpath($to)."/".$filen ;
		if(!is_file($fromfile))
			{
			return "<message text='$from file is not exist.' error='1' refresh='$last'/>\n";
			}
		if(is_file($tofile)&&$confirm=='1')
			{
			return "<message text='$tofile file is exist. Do you want to owerwrite?' error='1' refresh='$last' confirm='1' from='$fromfile' to='$to'/>\n";
			}
		
		if(copy($fromfile, $tofile)) return ("<message text='$fromfile file is copied to $tofile' error='0' refresh='$last'/>");
			return "<message text='$from file is cannot copied to $tofile' error='1' refresh='$last'/>\n";
		}
		
	function copydir($data)
		{
		$data=stripslashes('<?xml version="1.0"?> '.$data);
		$parser = xml_parser_create();
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, $data, $vals, $index);
		xml_parser_free($parser); 
		//$xml = simplexml_load_string($data);
		$from = $vals[0]["attributes"]["FROM"];
		$to = $vals[0]["attributes"]["TO"];
		$last = $vals[0]["attributes"]["LAST"];
		$confirm = $vals[0]["attributes"]["CONFIRM"];
		global $_SERVER;
		$from_ = realpath( $from );
		$to_  =  realpath( $to);
		$fromdir= explode("/", $from_);
		$newdir = $fromdir[count($fromdir)-1];
		if(!mkdir($to_."/".$newdir))  return "<message text='Cannot create $to_."/".$newdir directory.' error='1' refresh='$last'/>\n";
		else $st.= "<message text='".$to_."/".$newdir." directory created.' error='0' refresh='$last'/>\n";
		$i =0;
		if(is_dir($from_))
			{
				if ($k_azon = opendir($from_)) {
				while (false !== ($fajl = readdir($k_azon))) {
					$i++;
					$fromfile = $from_ ."/".$fajl;
					$tofile = $to."/".$newdir."/".$fajl;
					if(filetype($fromfile)=="dir"&& $fajl!=".." && $fajl!=".") copydir ("<copy from='".$fromfile."' to='".$to."/".$newdir."' last='$last'>");
					if(filetype($fromfile)!="dir")
					{
					if(!is_file($fromfile))
						{
						$st.= "<message text='$fromfile file is not exist.' error='1' refresh='$last'/>\n";
						}
				if(copy($fromfile, $tofile)) $st.= "<message text='$i  $fromfile file is copied to $tofile' error='0' refresh='$last'/>";
				else	$st.= "<message text='$fromfile file is cannot copied to $tofile' error='1' refresh='$last'/>\n";
					
					}
				   }
				   closedir($k_azon);
				   echo $st;
				   return  false;
				}
				else {
				echo $st."<message text='$from_ cannot open.' error='1' refresh='$last'/>\n";
				return false;
				}
				
			}
		else {
		echo  $st."<message text='$from_ directory is not exists.' error='1' refresh='$last'/>\n";
		return false;
			}
		}
function rn($data)
	{
		echo "<?xml version=\"1.0\"?>";
		$data=stripslashes('<?xml version="1.0"?> '.$data);
		$parser = xml_parser_create();
		xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
		xml_parse_into_struct($parser, $data, $vals, $index);
		xml_parser_free($parser); 
		//$xml = simplexml_load_string($data);
		$old = $vals[0]["attributes"]["OLD"];
		$new =  $vals[0]["attributes"]["NEW"];
		$ssz = $vals[0]["attributes"]["SSZ"];
		if(rename($old,$new)) return "<message text='Rename ready.' error='0' ssz='$ssz'/>";
		else return "<message text='Cannot rename.' error='1' ssz='$ssz'/>";
	
	}
function get4edit($file)
	{
	@readfile($file);
	}
function cleanPath($path) {
   $result = array();
   // $pathA = preg_split('/[\/\\\]/', $path);
   $pathA = explode('/', $path);
   if (!$pathA[0])
       $result[] = '';
   foreach ($pathA AS $key => $dir) {
       if ($dir == '..') {
           if (end($result) == '..') {
               $result[] = '..';
           } elseif (!array_pop($result)) {
               $result[] = '..';
           }
       } elseif ($dir && $dir != '.') {
           $result[] = $dir;
       }
   }
   if (!end($pathA))
       $result[] = '';
   return implode('/', $result);
}




$sexport[]="listdir";	
$sexport[]="makedirectory";	
$sexport[]="deletefile";	
$sexport[]="copyfile";	
$sexport[]="deletedir";	
$sexport[]="copydir";	
$sexport[]="rn";	
$sexport[]="get4edit";	


?>