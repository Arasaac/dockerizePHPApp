<?
/**
 * AERFile:
 * 	PHP, AJAX based file manager
 *        To obtain more information, please visit: http://www.aer.hu
 *
 * @author              Roland BARKOCZI
 * @site		www.aer.hu
 * @date                2006/07
 * @lastmod              2006/08.09
 * @version             1.1 stable - some bugs fixed: run correctly with(error_reporting(E_ALL))
 */
 error_reporting (E_ALL);
	session_start();
	include "config.php";
	include "Sajax.php";
	include "functions.php";
	include "ftp_functions.php";
if(isset($_POST["enter"]))
	{
	if($_POST["loginname"]==$username&&$_POST["pwd"]==$password ) $_SESSION["ID"]='OK';
	else $error.="\\nAcces denied: incorrect login/password combination!";
	}
if(isset($_GET["exit"]))unset( $_SESSION["ID"]);


	$sajax_request_type = "GET";
	sajax_init();
	//$sajax_debug_mode = 1; 
	if(is_array($sexport))
	foreach ($sexport as $k=>$r)
		if($r)sajax_export($r);
	sajax_handle_client_request(); 

?>

<!DOCTYPE html
PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="hu" >
<head>
<title>AerFM</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="LoadVars.js"></script>
<script type="text/javascript" src="BytesUploaded.js"></script>
<script type="text/javascript"  src = "yui/yahoo.js" ></script>
<script type="text/javascript"  src = "yui/dom.js" ></script>
<script type="text/javascript" src = "yui/event.js" ></script>
<script type="text/javascript"  src = "yui/dragdrop.js"></script>
<script type="text/javascript" src = "yui/DDResize.js"></script>
<script type="text/javascript"><!--
  <?
    sajax_show_javascript();
  ?>
  var dd1 = new YAHOO.util.DD("makedir", "panel");  
       dd1.addInvalidHandleId("dirname");

  
var dd2 = new YAHOO.util.DD("renameform", "panel2");  
       dd2.addInvalidHandleId("name");

var dd3 = new YAHOO.util.DD("upload", "panel3");  
       dd2.addInvalidHandleId("uploadfile");
       
var dd5 = new YAHOO.util.DD("fileviewer", "panel4");  
	dd5.addInvalidHandleId("filetext");

var dd6 = new YAHOO.util.DD("ftp", "panel5");  
     dd6.addInvalidHandleId("server");
     dd6.addInvalidHandleId("user");
     dd6.addInvalidHandleId("pwd");

var dd7 = new YAHOO.util.DD("login", "panel7");  
     dd7.addInvalidHandleId("loginname");
     dd7.addInvalidHandleId("pwd");

dd = new YAHOO.example.DDResize("picturecont", "handleDiv", "panelresize");
//dd_ = new YAHOO.example.DDResize("picturewrapper", "handleDiv", "panelresize");
var dd4 = new YAHOO.util.DD("picturecont");    
     dd4.addInvalidHandleId("handleDiv");
     dd4.addInvalidHandleId("picturecont");
     dd4.addInvalidHandleId("picturewrapper");
    
	    
	    
var bUploaded = new BytesUploaded('whileuploading.php',100);
var selectedFiles = new Array();
var filearray = new Array();
var path = new Array();
path["right"]="<? echo  $startdirectory_rigth?>";
path["left"]="<? echo $startdirectory_left?>";

var activeFrame = "left";
var passiveFrame = "right";
var ftp_connection = false;
var server = "";
var user = "";
var pwd = "";
function printfire()
{
    if (document.createEvent)
    {
        printfire.args = arguments;
        var ev = document.createEvent("Events");
        ev.initEvent("printfire", false, true);
        dispatchEvent(ev);
    }
}
function message(o)
	{
	document.getElementById("messages").innerHTML =o+document.getElementById("messages").innerHTML ;
	}
function getSelectTotal()
	{
	var total=0;
	for (var i in selectedFiles[activeFrame])
	if(selectedFiles[activeFrame][i])total++;
	return total;
	}
function gettime()
	{
	var timestamp = new Date();
	var year = timestamp.getYear()+1900;
	var ho = timestamp.getMonth()+1;
	var nap = timestamp.getDate();
	var ora = timestamp.getHours();
	var perc = timestamp.getMinutes();
	var mp = timestamp.getSeconds();
	if(ho<10) ho = "0"+ho;
	if(nap<10) nap = "0"+nap;
	if(ora<10) ora = "0"+ora;
	if(perc<10) perc = "0"+perc;
	if(mp<10) mp = "0"+mp;
	return  year+"-"+ho+"-"+nap+", "+ora+":"+perc+":"+mp;
	}


function getmimetype(filename)
	{
	if(filename=="dir")
		return "<img src='img/folder_blue.png' alt='dir'>";
	filename = filename.toLowerCase();
	if (filename=="doc")	return "<img src='img/doc.png' alt='doc'>";
	if (filename=="exe")	return "<img src='img/exec_wine.png' alt='exe'>";
	if (filename=="ttf")	return "<img src='img/gettext.png' alt='ttf'>";
	if (filename=="htm"||filename=="html") return "<img src='img/html.png' alt='html'>";
	if (filename=="jpg"||filename=="png"||filename=="bmp"||filename=="gif") return "<img src='img/images.png' alt='Images'>";
	if (filename=="mpg"||filename=="avi") return "<img src='img/video.png' alt='video'>";
	if (filename=="pdf") return "<img src='img/pdf.png' alt='pdf'>";
	if (filename=="wav"||filename=="mp3") return "<img src='img/sound.png' alt='sound'>";
	if (filename=="tar"||filename=="zip") return "<img src='img/tar.png' alt='compressed'>";
	if (filename=="swf" ) return "<img src='img/swf.png' alt='swf'>";
	return "<img src='img/ascii.png' alt='ascii'>";
	}
	
function selectitem(side, i)
	{
	if(selectedFiles[side][i]==undefined) 
		{
		document.getElementById(side+"_"+i).className="pointed";
		selectedFiles[side][i]=i;
		}
	else
		{
		document.getElementById(side+"_"+i).className="tr";
		delete selectedFiles[side][i];
		lehet = 1;
		for(z in selectedFiles[side])
			if( selectedFiles[side][z]) lehet=0;
		if(lehet) selectedFiles[side]= new Array();
		}
	}

function refreshleft_cb(o)
	{
	if(o.length>3)
	{
	var xmlobject = (new DOMParser()).parseFromString(o, "text/xml");
	var directory = xmlobject.getElementsByTagName("directory");
	var side = directory[0].getAttribute("side");
	 path[side] = directory[0].getAttribute("path");
	var items = xmlobject.getElementsByTagName("entry");
	html ='<table>';
	filearray[side]  = null;
	selectedFiles[side]=null;
	filearray[side]  = new Array();
	selectedFiles[side] = new Array();
	for (var i = 0 ; i < items.length ; i++) {
		var item = items[i];
		filearray[side][i] = new Array();
		filearray[side][i]["name"]=item.getAttribute("name");
		filearray[side][i]["type"]=item.getAttribute("type");
		html +="<tr id='"+side+"_"+i+"' onclick='selectitem(\""+side+"\","+i+")'  ondblclick='openitem(\""+side+"\","+i+")'>";
		html +="<td class='icon'>"+getmimetype(item.getAttribute("type"))+"</td>";
		html +="<td class='name'>"+item.getAttribute("name")+"</td>";
		html +="<td class='size'>"+item.getAttribute("size")+"</td>";
		html +="<td class='ctime'>"+item.getAttribute("ctime")+"</td>";
		html +="<td class='perms'>"+item.getAttribute("perms")+"</td>";
		html +="</tr>";
		} 
	html +='<table>';
	document.getElementById(side+"Frame").innerHTML=html;
	var pathfrag = path[side].split("/");
	var st="";
	if(ftp_connection&&side=="left") st=user+"@"+server+":";
	var pat="" ;
	for(var i in pathfrag)
		{
		pat+=pathfrag[i]+"/";
		st += "<a href='#' onclick='openpath(\""+side+"\",\""+pat+"\"); return false'>"+pathfrag[i]+"</a>/";
		}
	document.getElementById(side+"Framecont").firstChild.innerHTML=st;
	return true;
	}
	message( "<span class='error'>"+gettime()+"&gt; Cannot open directory.</span><br/>");
	return false;
	}

function getdir( side)
	{
	if(side=='left'&&ftp_connection)
	x_listdir("<entry path='"+ path[side]+"' side = '"+side+"' server='"+server+"' user='"+user+"' pwd='"+pwd+"' />",refreshleft_cb);
	else
	x_listdir("<entry path='"+ path[side]+"' side = '"+side+"' />",refreshleft_cb);
	}
function selectframe(side)
	{
	activeFrame= side;
	if(side=="right")
	passiveFrame= "left";
	else passiveFrame= "right";
	document.getElementById("leftFramecont").firstChild.className=null;
	document.getElementById("rightFramecont").firstChild.className=null;
	document.getElementById(side+"Framecont").firstChild.className="activeFrame";
	}
function openpath(side, pat)	
	{
	path[side]=pat;
	getdir(side);
	}
	
function openitem(side, i)
	{
	window.getSelection().removeAllRanges();
	if(filearray[activeFrame][i]["type"]=='dir')
		{
		path[activeFrame]+="/"+filearray[activeFrame][i]["name"];
		getdir(activeFrame);
		}
	else if(filearray[activeFrame][i]["type"]=='jpg'
	||filearray[activeFrame][i]["type"]=='png'
	||filearray[activeFrame][i]["type"]=='bmp'
	||filearray[activeFrame][i]["type"]=='gif'
	)
		{
		
		document.getElementById("picture").src = null;
		document.getElementById("picture").src ="picview.php?p="+path[activeFrame]+"/"+filearray[activeFrame][i]["name"];
		document.getElementById("picturecont").style.display = "block";
		document.getElementById("picnev").innerHTML= "";
		document.getElementById("picnev").innerHTML= filearray[activeFrame][i]["name"];
		document.getElementById("shutter").style.display="block";

		}
	else edit(i);
		
	}
/**************************************
konyvtar letrehozasa
**************************************/
function makedirectory()
	{
	document.getElementById("makedir").style.display="block";
	document.getElementById("shutter").style.display="block";
	document.getElementById("dirname").focus();
	}
function makedirectory_add()
	{
	var x = document.getElementById("dirname").value;
	x_makedirectory("<entry path='"+path[activeFrame]+"' dir='"+x+"'/>", makedirectory_cb);	
	}	
function makedirectory_cb(o)
	{
	if(o=="exist"){ alert("Directory already exist.") ;message( "<span class='error'>"+gettime()+"&gt; Directory already exist.</span><br/>");}
	if(o=="empty"){ alert("Please, give a valid directory name") ;message( "<span class='error'>"+gettime()+"&gt; Please, give a valid directory name.</span><br/>");}
	if(o=="error"){ alert("An uknown error occoured."); message(  "<span class='error'>"+gettime()+"&gt; An uknown error occoured.</span><br/>");}
	if(o=="ok")
		{
		getdir("left");
		getdir("right");
		makedirectory_cancel();
		message(  gettime()+"&gt; Directory created.<br/>");
		}
	}
function makedirectory_cancel()
	{
	document.getElementById("dirname").value="";
	document.getElementById("makedir").style.display="none";
	document.getElementById("shutter").style.display="none";	
	}
/**************************************
atnavezes
**************************************/

function rename()
	{
	if(selectedFiles[activeFrame].length>0)
	{
	document.getElementById("renameform").style.display="block";
	document.getElementById("shutter").style.display="block";
	for (i in selectedFiles[activeFrame])
		{
		if(selectedFiles[activeFrame][i]!=undefined)
			{
				document.getElementById("name").value = filearray[activeFrame][i]["name"];
				document.getElementById("namessz").value =i;
			break;	
			}
		}
	}
	else
		{
		alert("No selected files!");
		message("<span class='error'>"+  gettime()+"&gt; Rename: No selected files!</span><br/>");
		}
	}
	
function rename_add()
	{
	var x = document.getElementById("name").value;
	var y = document.getElementById("namessz").value;
	x_rn("<entry new='"+path[activeFrame]+"/"+x+"' old='"+path[activeFrame]+"/"+ filearray[activeFrame][ selectedFiles[activeFrame][y]]["name"]+"' ssz='"+y+"' />", rename_add_cb);	
	}
	
function rename_add_cb (o)
	{
	var xmlobject = (new DOMParser()).parseFromString(o, "text/xml");
	var items = xmlobject.getElementsByTagName("message");
	for (var i = 0 ; i < items.length ; i++) 
	{
		var item = items[i];
		if(item.getAttribute("error")=="1")
			{
			message("<span class='error'>"+  gettime()+"&gt; "+item.getAttribute("text")+"</span><br/>");
			}
		else
			{
			message( gettime()+"&gt;  "+item.getAttribute("text")+"<br/>");
			}
	var kov=0;
	for (i in selectedFiles[activeFrame])
		{
		if(i==item.getAttribute("ssz")){ kov=1; continue;}
			
		if(kov==1)	
			{
				kov=2;
				document.getElementById("name").value = filearray[activeFrame][i]["name"];
				document.getElementById("namessz").value =i;
				break;	
			}
		}
		if(kov==1)
			{
			rename_cancel();
			}
	}
	}

function rename_cancel()
	{
	getdir("left");
	getdir("right");
	document.getElementById("name").value="";
	document.getElementById("namessz").value="0";
	document.getElementById("renameform").style.display="none";
	document.getElementById("shutter").style.display="none";
	}	
/**************************************
feltoltes
**************************************/	
function upload()
	{
	document.getElementById("upload").style.display="block";
	document.getElementById("shutter").style.display="block";
	document.getElementById('savepath').value = path[activeFrame];
	}
function upload_cancel()
	{
	document.getElementById("upload").style.display="none";
	document.getElementById("shutter").style.display="none";
	}	
function upload_end(mess)
	{
	getdir("left");
	getdir("right");
	bUploaded.stop();
	document.getElementById("fileprogress").innerHTML = mess;
	}
/**************************************
letoltes
**************************************/	
function download()
	{
	if(selectedFiles[activeFrame].length>0)
	{
	for (i in selectedFiles[activeFrame])
		{
		if(selectedFiles[activeFrame][i]!=undefined&&filearray[activeFrame][i]['type']!="dir")
			{
				window.open("downloader.php?file="+path[activeFrame]+"/"+filearray[activeFrame][i]["name"]);
			}
		}
	}
	else
		{
		alert("No selected files!");
		message("<span class='error'>"+  gettime()+"&gt; Rename: No selected files!</span><br/>");
		}
	}

function download_cb(o)
	{
	return true;
	}
/**************************************
torles
**************************************/	
function unlink(side)
	{
		if(selectedFiles[activeFrame].length)
		{
		if(confirm("Are you sure?"))
		{
		var total = getSelectTotal();
		var last;
		var z=0;
		for (var i in selectedFiles[activeFrame])
			{
				z++;
				if(z==total) last=1;
				else last = 0;
				if(filearray[activeFrame][i]["type"]=='dir')
					x_deletedir("<message dir='"+path[activeFrame]+"/"+filearray[activeFrame][i]["name"]+"' last='"+last+"'/>", deletedir_cb);
				else
					x_deletefile("<message file='"+path[activeFrame]+"/"+filearray[activeFrame][i]["name"]+"' last='"+last+"'/>", deletefile_cb);
			}
		}
		}
	else 
	{
		alert("No selected files");
		message("<span class='error'>"+  gettime()+"&gt; Delete: No selected files!</span><br/>");
	}
	}
function deletefile_cb(o)
	{
	var xmlobject = (new DOMParser()).parseFromString(o, "text/xml");
	var items = xmlobject.getElementsByTagName("message");
	for (var i = 0 ; i < items.length ; i++) {
		var item = items[i];
		if(item.getAttribute("error")=="1")
			{
			message("<span class='error'>"+  gettime()+"&gt; "+item.getAttribute("text")+"</span><br/>");
			}
		else
			{
			message( gettime()+"&gt;  "+item.getAttribute("text")+"<br/>");
			}
		if(item.getAttribute("refresh")=='1')
			{
			getdir("left");
			getdir("right");
			}
		}
	}
function deletedir_cb(o)
	{
	o='<? echo '<?xml version="1.0"?>';?>'+"<data>"+o+"</data>";
	
	
	var xmlobject = (new DOMParser()).parseFromString(o, "text/xml");
	var items = xmlobject.getElementsByTagName("message");
	for (var i = 0 ; i < items.length ; i++) {
		var item = items[i];
		if(item.getAttribute("error")=="1")
			{
			message("<span class='error'>"+  gettime()+"&gt; "+item.getAttribute("text")+"</span><br/>");
			}
		else
			{
			message( gettime()+"&gt;  "+item.getAttribute("text")+"<br/>");
			}
		if(item.getAttribute("refresh")=='1')
			{
			getdir("left");
			getdir("right");
			}
		} 
	}	
/**************************************
masolas
**************************************/	
function copy(side)
	{
		if(selectedFiles[activeFrame].length)
		{
		var total = getSelectTotal();
		var last;
		var z=0;
		
		for (var i in selectedFiles[activeFrame])
			{
			
			if(selectedFiles[activeFrame][i])
				{
				z++;
				if(z==total) last=1;
				else last = 0;
				if(filearray[activeFrame][i]["type"]=='dir')
					x_copydir("<copy confirm='1' from='"+path[activeFrame]+"/"+filearray[activeFrame][i]["name"]+"' to='"+path[passiveFrame]+"' last='"+last+"'/>", copydir_cb);
				else
					x_copyfile("<copy confirm='1' from='"+path[activeFrame]+"/"+filearray[activeFrame][i]["name"]+"' to='"+path[passiveFrame]+"' last='"+last+"'/>", copyfile_cb);
				}
			}
		}
		else {
		alert("No selected files");
		message("<span class='error'>"+  gettime()+"&gt; Copy: No selected files!</span><br/>");
		}
	}
function copyfile_cb(o)
	{
	var xmlobject = (new DOMParser()).parseFromString(o, "text/xml");
	var items = xmlobject.getElementsByTagName("message");
	for (var i = 0 ; i < items.length ; i++) {
		var item = items[i];
		if(item.getAttribute("error")=="1")
			{
			message("<span class='error'>"+  gettime()+"&gt; "+item.getAttribute("text")+"</span><br/>");
			if(item.getAttribute("confirm")=='1')
			{
					if(confirm(item.getAttribute("text")))
					{
					message(gettime()+"&gt; Yes<br/>");
					x_copyfile("<copy confirm='0' from='"+item.getAttribute("from")+"' to='"+item.getAttribute("to")+"' last='"+item.getAttribute("refresh")+"'/>", copyfile_cb);
					}
				else message("<span class='error'>"+  gettime()+"&gt; No</span><br/>");
				}
			}
		else
			{
			message( gettime()+"&gt;  "+item.getAttribute("text")+"<br/>");
			}
		if(item.getAttribute("refresh")=='1')
			{
			getdir("left");
			getdir("right");
			}
		}
	}
function copydir_cb(o)
	{
	o='<? echo '<?xml version="1.0"?>';?>'+"<data>"+o+"</data>";
	
	
	var xmlobject = (new DOMParser()).parseFromString(o, "text/xml");
	var items = xmlobject.getElementsByTagName("message");
	for (var i = 0 ; i < items.length ; i++) {
		var item = items[i];
		if(item.getAttribute("error")=="1")
			{
			message("<span class='error'>"+  gettime()+"&gt; "+item.getAttribute("text")+"</span><br/>");
			}
		else
			{
			message( gettime()+"&gt;  "+item.getAttribute("text")+"<br/>");
			}
		if(item.getAttribute("refresh")=='1')
			{
			getdir("left");
			getdir("right");
			}
		} 
	}
/**************************************
szerkesztes
**************************************/	
 function edit(file)
	{
	document.getElementById("fileviewer").style.display="block";
	document.getElementById("shutter").style.display="block";
	document.getElementById("filetext").select();
	
	x_get4edit(path[activeFrame]+"/"+filearray[activeFrame][file]["name"], edit_cb);
	document.getElementById("filenev").innerHTML=filearray[activeFrame][file]["name"];
	document.getElementById("path").value=path[activeFrame]+"/"+filearray[activeFrame][file]["name"];
		
	}
  function edit_cancel()
	{
	document.getElementById("fileviewer").style.display="none";
	document.getElementById("shutter").style.display="none";
	document.getElementById("filetext").value="";
	
	}
 function edit_cb(h)
	{
	document.getElementById("filetext").value=h;
	}
function edit_end(q)
	{
	alert(q);
	if(q=='File saved!')
		{
		document.getElementById("fileviewer").style.display="none";
		document.getElementById("shutter").style.display="none";
		document.getElementById("filetext").value="";
		}
	}
/**************************************
ftp kapcsolat
**************************************/	
function ftp_show()
	{
	document.getElementById("ftp").style.display="block";
	document.getElementById("shutter").style.display="block";
	}
  function ftp_cancel()
	{
	document.getElementById("ftp").style.display="none";
	document.getElementById("shutter").style.display="none";
	}
	
function ftp_connect()
	{
	if(!ftp_connection)
	{
	selectframe('left');
	 server = document.getElementById("server").value;
	 user = document.getElementById("user").value;
	 pwd = document.getElementById("pwd").value;
	if(!server.length)
		{
		alert("Please, give a real server name!");
		return false;
		}
	if(!user.length)
		{
		alert("Please, give an user name!");
		return false;
		}
	if(!pwd.length)
		{
		alert("Please, give a password!");
		return false;
		}
	x_tryftp("<entry server='"+server+"' user='"+user+"' pwd='"+pwd+"'/>",ftp_connect_cb);	
	}
	else
		{
		ftp_connection=false;
		document.getElementById("connectbutton").value="Connect";
		pwd = document.getElementById("pwd").value="";
		
		path["left"]="<? echo $startdirectory_left?>";
		getdir('left');
		}
	}
function ftp_connect_cb(q)
	{

	alert(q);
	if(q=='Connected!')
		{
		document.getElementById("connectbutton").value="Disconnect";
		path["left"]=".";
		message(q);
		ftp_connection=true;
		ftp_cancel();
		getdir('left');
		}
	}
	
 document.onselectstart=new Function ("return false");
 
 

-->
</script>
</head>
<?
	if(isset($_SESSION["ID"]))
	{ ?>
<body onload='getdir( "left"); getdir("right");'>
<div  id="shutter" >
</div>
<div  id="leftFramecont"  onclick="selectframe('left')"  ><h1 class="activeFrame" >Left</h1>
	<div id="leftFrame">
	
	</div>
</div>
<div  id="rightFramecont" onclick="selectframe('right')"><h1>Right</h1>
	<div id="rightFrame">
	
	</div>
</div>
<div  id="controlcont">
	<div id="controlFrame">
	<a href="#" onclick='makedirectory(); return false;'><img src='img/edit_add.png' alt='New directory'/>New directory</a>
	<a href="#" onclick='upload(); return false;'><img src='img/1uparrow.png' alt='Upload'/>Upload</a>
	<a href="#" onclick='download(); return false;'><img src='img/1downarrow.png' alt='Upload'/>Download</a>
	<a href="#" onclick='rename(); return false;'><img src='img/cell_edit.png' alt='Rename'/>Rename</a>
	<a href="#" onclick='copy(); return false;'><img src='img/editcopy.png' alt='Rename'/>Copy</a>
	<a href="#" onclick='unlink(); return false;'><img src='img/kuka.png' alt='Delete'/>Delete</a>
	<!--<a href="#" onclick='ftp_show();' id='ftp_off'><img src='img/server.png' alt='Edit'/>FTP connection</a>-->
	<a href="index.php?exit=1"><img src='img/exit.png' alt='Log out'/>Log out</a>
	<div id='logo'>
	<a href='http://www.aer.hu' target="_blank">AER</a>
	<a href="http://getfirefox.com/"
title="Get Firefox - The Browser, Reloaded." target="_blank"><img src="http://www.mozilla.org/products/firefox/buttons/firefox_80x15.png" alt="Get Firefox"/></a> </center>	
	
	</div>
	</div>
</div>

<div  id="messagescont">
	<img id='delmessage' src='img/kuka.png' alt='Clear message box' onclick =' document.getElementById("messages").innerHTML=""'/>
	<div  id="messages">
	</div>
</div>

<form id="makedir" action="index.php" onsubmit="makedirectory_add(); return false;">
<img src='img/cancel.png' onclick='makedirectory_cancel()' class="cancel2"  alt='cancel'/>	
	<fieldset>
		<legend>Make new directory</legend>
		<label for="dirname">Name:</label>
		<input type="text" id="dirname" name="dirname"/>
		<input type="button" value="OK" onclick="makedirectory_add()"/>
		<input type="button" value="Cancel" onclick="makedirectory_cancel()"/>
	</fieldset>
</form>

<form id="renameform" action="index.php" onsubmit="rename_ok(); return false;">
<img src='img/cancel.png' onclick='rename_cancel()' class="cancel2" alt='cancel'/>	
	<fieldset>
		<legend>Rename</legend>
		<label for="dirname">Name:</label>
		<input type="text" id="name" name="name"/>
		<input type="hidden" id="namessz" name="namessz" value='0'/>
		<input type="button" value="OK" onclick="rename_add()"/>
		<input type="button" value="Cancel" onclick="rename_cancel()"/>
	</fieldset>
</form>

<form id="upload" enctype="multipart/form-data" method="post"  action="fileuploader.php" target='uploadframe' onsubmit="bUploaded.start('fileprogress');">
<img src='img/cancel.png' onclick='upload_cancel()' class="cancel2"  alt='cancel'/>	<h1 id="cimsor" class="cimsor">File upload</h1>

	<fieldset>
		<label for="uploadfile">File: </label>
		<input type="file" id="uploadfile" name="uploadfile"/>
		<input type="hidden" name="savepath" id="savepath"/>
		<input type="submit" value="OK" />
		<input type="button" value="Cancel" onclick="upload_cancel()"/>
			<div id="fileprogress" style="font-weight: bold;">&nbsp;</div>

	</fieldset>
</form>
<iframe id="uploadframe" name="uploadframe"></iframe>

<div id='picturecont'>
<img alt='cancel' src='img/cancel.png' onclick='document.getElementById("picturecont").style.display="none"; document.getElementById("shutter").style.display="none";' class="cancel"/>
<h1 id="picnev" class="cimsor"></h1>
<div id='picturewrapper'>
	<img id="picture"  alt='.'/>
	        <div id="handleDiv"></div>
</div></div>

<form id='fileviewer' action='editfile.php' enctype="multipart/form-data" method="post"  target='uploadframe'>
<img src='img/cancel.png' onclick='edit_cancel()' class="cancel"/>
<h1 id="filenev" class="cimsor">Filenev</h1>
	<textarea name="filetext" id="filetext" cols='97' rows='28'></textarea>
	<input type='hidden' name='path' id='path' value=''/>
	<input type='submit' value='Save'/>
	<input type='button' value='Close' onclick='edit_cancel()' />
</form>

<form id='ftp' action='index.php'>
<img  alt='cancel' src='img/cancel.png' onclick='ftp_cancel()' class="cancel2"/>
<h1 id="ftpnev" class="cimsor">FTP connection parameters</h1>
<fieldset>
<label for="server">Remote server: </label><input type="text" id="server" name="server"/><br/>
<label for="user">User name: </label><input type="text" id="user" name="user"/><br/>
<label for="pwd">Password: </label><input type="password" id="pwd" name="pwd"/><br/>
<input type='button' value='Connect' onclick='ftp_connect()' id="connectbutton" />
<input type='button' value='Cancel' onclick='ftp_cancel()' />
</fieldset>
</form>

</body>
<?
}else{?>
<body>
<?
if(isset($error))
	{
	?>
	<script type="text/javascript" >alert('<?=$error?>')</script>
	<?
	}
?>
	<form name='login' id='login' action='index.php' enctype="multipart/form-data" method="post" >
		<h1 id="loginnev" class="cimsor"> aerFM Login</h1>
		<fieldset>
		
		<label for="loginname">Login name: </label><input type="text" id="loginname" name="loginname"/><br/>
		<label for="pwd">Password: </label><input type="password" id="pwd" name="pwd"/><br/>
		<input type='submit' value='Enter' name='enter'/>
		</fieldset>
		<center>
		Version 1.1<br/>
		<a href="http://www.aer.hu" target="_blank">www.aer.hu</a><br/>
		Works only with Firefox!
<br/><a href="http://getfirefox.com/"
title="Get Firefox - The Browser, Reloaded."><img src="http://www.mozilla.org/products/firefox/buttons/firefox_80x15.png" alt="Get Firefox"/></a> </center>	
	</form>
</body>
<?
}
?></html>
