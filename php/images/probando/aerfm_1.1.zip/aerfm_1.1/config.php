<?
$username = 'user';
$password = 'passwords';
$error="";
$tmpdir = ini_get ("upload_tmp_dir");
if (function_exists('realpath') &&function_exists('dirname') )
{
$startdirectory_left=realpath(dirname($_SERVER["PATH_TRANSLATED"]));
$startdirectory_rigth=realpath(dirname($_SERVER["PATH_TRANSLATED"]));
}
else
{
$startdirectory_left="";
$startdirectory_rigth="";
$error .= "This apllication needs the realpath() function, which is not authorised on this server. Please, keep contact with the system administrator!";
}
?>